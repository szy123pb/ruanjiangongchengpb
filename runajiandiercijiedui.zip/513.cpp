#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
using  namespace std;
int intrand(int x)
{
    if (x == 10)
        return rand() % 10 + 1;
    else
        return rand() % 100 + 1;
}
float floatrand(int x)
{
    float y;
    if (x == 10)
    {
        y = (rand() % 1000 + 1);
        y = y / 100;
        return y;
    }
    else
    {
        y = (rand() % 10000 + 1);
        y = y / 100;
        return y;
    }
}
void bpri(int n, int max, int op, char* oper, int bark, int fl)
{
    int i, j, a, b = 0, l;
    l = strlen(oper);
    for (i = 0; i < n; i++)
    {
        if (fl == 1)
        {
            for (j = 0; j < op; j++)
            {
                a = rand() % l;
                if (bark == 1)
                    b = rand() % 2;
                if (b == 1)
                {
                    printf("(%d%c%d)", intrand(max), oper[a], intrand(max));
                    j++;
                    if (j == op)
                    {
                        printf("=\n");
                        b = 2;
                    }
                    else
                    {
                        a = rand() % l;
                        printf("%c", oper[a]);
                    }
                }
                else
                {
                    printf("%d%c", intrand(max), oper[a]);
                }
            }
            if (b != 2)
                printf("%d=\n", intrand(max));
        }
        else
        {
            for (j = 0; j < op; j++)
            {
                a = rand() % l;
                if (bark == 1)
                    b = rand() % 2;
                if (b == 1)
                {
                    printf("(%.2f%c%.2f)", floatrand(max), oper[a], floatrand(max));
                    j++;
                    if (j == op)
                    {
                        printf("=\n");
                        b = 2;
                    }
                    else
                    {
                        a = rand() % l;
                        printf("%c", oper[a]);
                    }
                }
                else
                {
                    printf("%.2f%c", floatrand(max), oper[a]);
                }
            }
            if (b != 2)
                printf("%.2f=\n", floatrand(max));
        }
    }
}
void fpri(int n, int max, int op, char* oper, int bark, int fl, FILE* fp)
{
    int i, j, a, b = 0, l;
    l = strlen(oper);
    for (i = 0; i < n; i++)
    {
        if (fl == 1)
        {
            for (j = 0; j < op; j++)
            {
                a = rand() % l;
                if (bark == 1)
                    b = rand() % 2;
                if (b == 1)
                {
                    fprintf(fp, "(%d%c%d)", intrand(max), oper[a], intrand(max));
                    j++;
                    if (j == op)
                    {
                        fprintf(fp, "=\n");
                        b = 2;
                    }
                    else
                    {
                        a = rand() % l;
                        fprintf(fp, "%c", oper[a]);
                    }
                }
                else
                {
                    fprintf(fp, "%d%c", intrand(max), oper[a]);
                }

            }
            if (b != 2)
                fprintf(fp, "%d=\n", intrand(max));
        }
        else
        {
            for (j = 0; j < op; j++)
            {
                a = rand() % l;
                if (bark == 1)
                    b = rand() % 2;
                if (b == 1)
                {
                    fprintf(fp, "(%.2f%c%.2f)", floatrand(max), oper[a], floatrand(max));
                    j++;
                    if (j == op)
                    {
                        fprintf(fp, "=\n");
                        b = 2;
                    }
                    else
                    {
                        a = rand() % l;
                        fprintf(fp, "%c", oper[a]);
                    }
                }
                else
                {
                    fprintf(fp, "%.2f%c", floatrand(max), oper[a]);
                }

            }
            if (b != 2)
                fprintf(fp, "%.2f=\n", floatrand(max));
        }

    }
}
int main()
{
   
    int n, max = 0, op, bark = 0, fl, fil;
    char oper[10];
    printf("����������ʽ�ӵ�����\n");
    scanf_s("%d", &n);
    while (1)
    {
        printf("����������ʽ�����ֵ����ֵ��10��100��\n");
        scanf_s("%d", &max);
        if (max == 10 || max == 100)
            break;
        printf("������������������\n");
    }
    while (1)
    {
        printf("�������������������1-4��\n");
        scanf_s("%d", &op);
        if (op >= 1 && op <= 4)
            break;
        printf("������������������\n");
    }
    printf("��������Ҫ���������+��-��*��/����\n");
    getchar();
    gets_s(oper);
    if (op > 1)
    {
        while (1)
        {
            printf("�Ƿ���Ҫ���ţ�1=��Ҫ��0=����Ҫ��\n");
            scanf_s("%d", &bark);
            if (bark == 1 || bark == 0)
                break;
            printf("������������������\n");
        }
    }
    while (1)
    {
        printf("ѡ���������ͣ�1=������2=С����\n");
        scanf_s("%d", &fl);
        if (fl == 1 || fl == 2)
            break;
        printf("������������������\n");
    }
    bpri(n, max, op, oper, bark, fl);
    while (1)
    {
        printf("�Ƿ�Ҫ������ļ��ڣ�1=�ǣ�0=��\n");
        scanf_s("%d", &fil);
        if (fil == 1 || fil == 0)
            break;
        printf("������������������\n");
    }
    if (fil == 1)
    {
        FILE* fp;
        errno_t err;
        err = fopen_s(&fp, "E:\\Study\\1.txt", "w");
        fpri(n, max, op, oper, bark, fl, fp);
        fclose(fp);
        printf("����ɹ�������ļ��鿴���");
    }
    else
        bpri(n, max, op, oper, bark, fl);
    system("pause");
    return 0;
}